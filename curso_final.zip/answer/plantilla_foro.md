## Plantilla de foro (consigna, reglas, rúbrica breve)
**Consigna**: comparte un gráfico propio (barras/histograma) usando datos de tu contexto y comenta dos aportes de compañeros.
**Reglas**: respeto, citas de fuente, no publicar datos sensibles.
**Rúbrica (0-3)**:
- 0: sin evidencias / fuera de tema
- 1: gráfico incompleto / sin fuente
- 2: gráfico correcto / comentario básico
- 3: gráfico claro / comentario crítico con sugerencias
