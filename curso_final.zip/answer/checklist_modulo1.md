## Checklist de estudio semanal (4 semanas por módulo)
**Uso**: marca cada paso al avanzar en el módulo. Imprime o convierte a PDF.
| Semana | Tarea | Hecho |
|---|---|---|
| 1 | Leer guía y registrar dudas | [ ] |
| 1 | Ver recursos (videos/lecturas) | [ ] |
| 2 | Resolver ejercicios guiados | [ ] |
| 2 | Participar en foro | [ ] |
| 3 | Practicar con datos locales | [ ] |
| 3 | Entregar actividad formativa | [ ] |
| 4 | Realizar cuestionario y autoevaluación | [ ] |
| 4 | Preparar miniinforme | [ ] |
