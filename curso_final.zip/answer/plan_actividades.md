## Plan de actividades (formato editable para estudiantes)
**Uso**: completa fechas y productos. Convierte a PDF si necesitas imprimir.
| Semana | Actividad | Producto/Entrega | Fecha | Responsable | Observaciones |
|---|---|---|---|---|---|
| 1 | Lecturas y notas | Síntesis 1 página | | | |
| 2 | Práctica guiada | Hoja de cálculo | | | |
| 3 | Proyecto aplicado | Borrador de análisis | | | |
| 4 | Presentación final | Informe y gráfico | | | |
